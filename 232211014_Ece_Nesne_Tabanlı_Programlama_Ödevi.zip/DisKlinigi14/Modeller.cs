﻿using Google.Cloud.Firestore;
using System;

namespace DisKlinigi14 
{
    
    public abstract class BaseModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string EklenmeTarihi { get; set; } = DateTime.Now.ToString("dd.MM.yyyy");
    }


    [FirestoreData]
    public class Hasta : BaseModel
    {
        [FirestoreProperty]
        public string AdSoyad { get; set; }
        [FirestoreProperty]
        public string Telefon { get; set; }
        [FirestoreProperty]
        public string DogumTarihi { get; set; }
        [FirestoreProperty]
        public string Cinsiyet { get; set; }
        [FirestoreProperty]
        public string Alerji { get; set; }
        [FirestoreProperty]
        public string Adres { get; set; }
    }

    [FirestoreData]
    public class Randevu : BaseModel
    {
        [FirestoreProperty]
        public string HastaAdSoyad { get; set; }
        [FirestoreProperty]
        public string Tarih { get; set; }
        [FirestoreProperty]
        public string Saat { get; set; }
        [FirestoreProperty]
        public string Tedavi { get; set; }
    }

    [FirestoreData]
    public class Tedavi
    {
        [FirestoreProperty]
        public string Id { get; set; }

        [FirestoreProperty]
        public string TedaviAdi { get; set; }

        [FirestoreProperty]
        public string Tutar { get; set; }

        [FirestoreProperty]
        public string Aciklama { get; set; }
    }

    [FirestoreData]

    public class Recete : BaseModel
    {
        [FirestoreProperty]
        public string HastaAdSoyad { get; set; }
        [FirestoreProperty]
        public string Ilaclar { get; set; }
        [FirestoreProperty]
        public string Tutar { get; set; }
        [FirestoreProperty]
        public string Miktar { get; set; }
    }
}