﻿using System;
using System.Windows.Forms;
using FireSharp.Response;
using FireSharp.Config;
using FireSharp.Interfaces;
using Newtonsoft.Json;

namespace DisKlinigi14
{
    public partial class ReceteFormu : Form
    {
        FirestoreHelper db = new FirestoreHelper();

        public ReceteFormu()
        {
            InitializeComponent();
        }

        
        private async void btnKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                
                Recete yeniRecete = new Recete
                {
                    HastaAdSoyad = txtAdSoyad.Text,
                    Ilaclar = txtIlaclar.Text,
                    Tutar = txtTutar.Text,
                    Miktar = txtMiktar.Text
                };

                await db.KayitEkle("Receteler", yeniRecete);

                MessageBox.Show("Reçete Yazıldı!");

                txtAdSoyad.Clear();
                txtIlaclar.Clear();
                txtTutar.Clear();
                txtMiktar.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {

            Anasayfa ana = new Anasayfa();
             ana.Show();
            this.Hide();
        }

        private void ReceteFormu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}