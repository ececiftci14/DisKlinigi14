﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Google.Cloud.Firestore;
using System.Threading.Tasks;
namespace DisKlinigi14
{
    public partial class TedaviFormu : Form
    {
        FirestoreHelper db = new FirestoreHelper();
       
        string secilenId = null;

        public TedaviFormu()
        {
            InitializeComponent();
        }

       
        private void TedaviFormu_Load(object sender, EventArgs e)
        {
            Listele();
            ButonKontrol();
        }

       
        private async void Listele()
        {
            try
            {
                
                CollectionReference tedaviRef = db.database.Collection("Tedaviler");
                QuerySnapshot snapshot = await tedaviRef.GetSnapshotAsync();

                List<Tedavi> tedaviListesi = new List<Tedavi>();

                foreach (DocumentSnapshot document in snapshot.Documents)
                {
                    if (document.Exists)
                    {
                       
                        Tedavi t = document.ConvertTo<Tedavi>();

                       
                        t.Id = document.Id;

                        tedaviListesi.Add(t);
                    }
                }

               
                dataGridView1.DataSource = tedaviListesi;

         
                if (dataGridView1.Columns["Id"] != null)
                {
                    dataGridView1.Columns["Id"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Listeleme Hatası: " + ex.Message);
            }
        }

       
        private async void btnKaydet_Click(object sender, EventArgs e)
        {
          
            if (string.IsNullOrEmpty(txtTedavi.Text) || string.IsNullOrEmpty(txtTutar.Text))
            {
                MessageBox.Show("Lütfen tedavi adı ve tutarını giriniz.");
                return;
            }

           
            btnKaydet.Enabled = false;
            btnKaydet.Text = "İşleniyor...";

            try
            {
               
                Tedavi veri = new Tedavi
                {
                    TedaviAdi = txtTedavi.Text,
                    Tutar = txtTutar.Text,
                    Aciklama = txtAciklama.Text
                };

                if (secilenId == null)
                {
                    
                    await db.database.Collection("Tedaviler").AddAsync(veri);
                    MessageBox.Show("Yeni tedavi başarıyla eklendi.");
                }
                else
                {
                   
                    DocumentReference docRef = db.database.Collection("Tedaviler").Document(secilenId);
                    await docRef.SetAsync(veri, SetOptions.Overwrite); 
                    MessageBox.Show("Tedavi güncellendi.");
                }

                
                Temizle();
                Listele();
                dataGridView1.ClearSelection();

            }
            catch (Exception ex)
            {
                MessageBox.Show("İşlem Hatası: " + ex.Message);
            }
            finally
            {
                btnKaydet.Enabled = true;
                btnKaydet.Text = "Kaydet";
            }
        }

        
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
          
            if (e.RowIndex >= 0)
            {
                
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                
                secilenId = row.Cells["Id"].Value.ToString();

                
                txtTedavi.Text = row.Cells["TedaviAdi"].Value.ToString();
                txtTutar.Text = row.Cells["Tutar"].Value.ToString();
                txtAciklama.Text = row.Cells["Aciklama"].Value.ToString();

              
                btnKaydet.Text = "Güncelle";
            }
            ButonKontrol();
        }

        
        private void Temizle()
        {
            txtTedavi.Clear();
            txtTutar.Clear();
            txtAciklama.Clear();

          
            secilenId = null;
            btnKaydet.Text = "Kaydet";
            ButonKontrol();
        }

       

        private void btnGeri_Click(object sender, EventArgs e)
        {
            Anasayfa ana = new Anasayfa();
            ana.Show();
            this.Hide();
        }

        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void ButonKontrol()
        {
            
            bool durum = (secilenId != null);

            button1.Visible = durum; 
            button2.Visible = durum;  

           
            if (durum)
            {
                btnKaydet.Text = "Güncelle";
               
            }
            else
            {
                btnKaydet.Text = "Kaydet";
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Temizle();
        }

        private async void button2_Click(object sender, EventArgs e)
        {
          
            if (secilenId == null)
            {
                MessageBox.Show("Lütfen silmek için listeden bir kayıt seçiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

       
            DialogResult cevap = MessageBox.Show("Bu tedaviyi kalıcı olarak silmek istediğinize emin misiniz?", "Silme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (cevap == DialogResult.Yes)
            {
                try
                {
                 
                    DocumentReference docRef = db.database.Collection("Tedaviler").Document(secilenId);
                    await docRef.DeleteAsync();

                    MessageBox.Show("Kayıt başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                   
                    Temizle();
                    Listele();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Silme işlemi sırasında hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void TedaviFormu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}